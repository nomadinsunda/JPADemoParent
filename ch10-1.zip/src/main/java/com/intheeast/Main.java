package com.intheeast;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.querydsl.core.Tuple;

import com.intheeast.entity.*;
import com.intheeast.utilities.JpaBooks;
import com.querydsl.jpa.impl.JPAQueryFactory;

public class Main {
	
	static final int TEAM_NUMBERS = 10;
	
	static final int MEMBER_NUMBERS = 100;

	static final int POST_NUMBERS = 10;
	static final int COMMENT_NUMBERS = 10;

	static final long POST_STRING_MAX_SIZE = 1500L;

	static final long COMMENT_STRING_MAX_SIZE = 300L;
	
	private static EntityManagerFactory emf = 
			Persistence.createEntityManagerFactory("jpabook");


	
	public static void main(String ...args) throws InterruptedException, IOException {
			
		
//		List<Long> membersIds = JpaBooks.initMemberTeamSampleData(emf,
//				TEAM_NUMBERS,
//				MEMBER_NUMBERS);
		
//		queryMemberOfTypedQuery();
//		queryColumnsOfQuery();
		
//		queryParameterBounding(membersIds);
		
//		useUserDTO();
		
//		testJPACriteria(membersIds);
		
//		getSingleRelationalShipEntity();
		
//		testInnerJoin();
		
//		testLeftOuterJoin();

//		testCrossJoin();
		
//		testAggregateFunction();
		
//		testGroupbyHavingOrderby();
		
//		setSubQueryInSelect();
		
//		testSubQueryInWhere();
		
//		testSubQueryInFromAlternate();

//		testQueryDSLUpdate();

//		testQueryDSLSelect();

//		testQueryDSLDelete();

//		testQueryDSLX();

//		testPagingAPIByJPQL();

//		testPagingAPIByQueryDSL();
//		testPaginaAPIWithoutOffsetByQueryDsl();

//		testFetchJoinByJPQL();

//		testFetchJoinByQueryDsl();

//		testCollectionFetchJoin();

//		List<Long> postIds = JpaBooks.initPostCommentSampleData(emf,
//				POST_NUMBERS,
//				POST_STRING_MAX_SIZE,
//				COMMENT_NUMBERS,
//				COMMENT_STRING_MAX_SIZE);

		JpaBooks.createPostAndCommentThroughChatGPT();
		
		emf.close();	
	}
	
	public static void queryMemberOfTypedQuery() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			TypedQuery<Member> query = 
					em.createQuery("Select m from Member m", Member.class);
			
			List<Member> members = query.getResultList();
			for (Member m: members) {
				System.out.printf("member id:%d, name:%s \n", m.getId(), m.getName());
			}
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}		
	}
	
	public static void queryColumnsOfQuery() {
		
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			Query query = 
					em.createQuery("Select m.name, m.age from Member m");
			
			// resultList의 엘리먼트가 오브젝트 배열: 이 엘리먼트의 엘리먼트 타입은 Object, 개수는 2개(name, age)
			List<Object[]> resultList = query.getResultList();
			for (Object[] result : resultList) {
				String name = (String)result[0];
				Integer age = (Integer)result[1];
				
				System.out.printf("name:%s, age:%d \n", name, age);
			}
			
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
		
	}
	
	public static void queryParameterBounding(List<Long> membersIds) {
		
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			Long memberId = JpaBooks.generateRandomID(membersIds);
			Member foundMember = em.find(Member.class, memberId);
			em.clear();
			
			String userNameParam = foundMember.getName();
			System.out.println("name = " + userNameParam);
			
			List<Member> members = 
					em.createQuery("Select m FROM Member m where m.name = :name",
							Member.class)
					.setParameter("name", userNameParam)
					.getResultList();
			
			for (Member m : members) {
				System.out.println("found name = " + m.getName());
			}
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
		
	}
	
	public static void useUserDTO() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			TypedQuery<UserDTO> query = 
					em.createQuery(
						"SELECT new com.intheeast.entity.UserDTO(m.name, m.age) FROM Member m", 
						UserDTO.class);
			
			List<UserDTO> resultList = query.getResultList();
			for (UserDTO d: resultList) {
				System.out.println("name = " + d.getName());
				System.out.println("age = " + d.getAge());
			}
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}
	
	
	public static void testJPACriteria(List<Long> membersIds) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			Long memberId = JpaBooks.generateRandomID(membersIds);
			Member foundMember = em.find(Member.class, memberId);
			em.clear();
			
			String name = foundMember.getName();
			System.out.println("name = " + name);
			CriteriaBuilder cb = em.getCriteriaBuilder();
			CriteriaQuery<Member> cq = cb.createQuery(Member.class);
			
			Root<Member> member = cq.from(Member.class);
			cq.
				select(member).
				where(cb.equal(member.get("name"), name));
			
			List<Member> members = em.createQuery(cq).getResultList();
			for(Member m: members) {
				System.out.println("member name: " + m.getName());
			}
			
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}
	
	public static void getSingleRelationalShipEntity() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();			
			
			TypedQuery<Team> query = 
					em.createQuery("SELECT m.team FROM Member m", Team.class);
			List<Team> teamList = query.getResultList();
			for (Team t: teamList) {
				System.out.println("Team name:" + t.getName());
			}			
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}
	
	public static void testInnerJoin() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			List<Team> teamList = 
					em.createQuery("Select distinct t from Member m join m.team t", 
							Team.class).getResultList();
			
			for (Team t: teamList) {
				System.out.println("team = " + t.getName());
			}
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}
	
	public static void testLeftOuterJoin() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
//			List<Member> memList = 
//					em.createQuery("Select m from Member m left outer join m.team t", 
//							Member.class).getResultList();
//			
//			for (Member m: memList) {
//				System.out.println("member name = " + m.getName());
//			}
			
			@SuppressWarnings("unchecked")
			List<Object[]> objsList = 
					em.createQuery("Select m, t from Member m left outer join m.team t")
					.getResultList();
			
			for (Object[] objs: objsList) {
				Member m = (Member) objs[0];
				Team t = (Team) objs[1];
				System.out.printf("member name:%s, team name:%s \n", 
						m.getName(), t.getName());
			}
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}
	
	public static void testCrossJoin() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			String query = "select m, t from Member m, Team t";
			
			@SuppressWarnings("unchecked")
			List<Object[]> objsList = 
					em.createQuery(query)
					.getResultList();
			
			for (Object[] objs: objsList) {
				Member m = (Member)objs[0];
				Team t = (Team)objs[1];
//				System.out.println("member:" + m + "team:" + t);				
			}
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}
	
	public static void testAggregateFunction() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			TypedQuery<Long> sumQuery = 
					em.createQuery("select sum(m.age) from Member m", Long.class);
			Long totalAge = sumQuery.getSingleResult();
			System.out.println("Sum of Age: " + totalAge);
			
			Double averageAge = 
					em.createQuery("select avg(m.age) from Member m", Double.class)
					.getSingleResult();
			System.out.println("Avg of Age: " + averageAge);

			Integer maxValue = 
					em.createQuery("select max(m.age) from Member m", Integer.class)
					.getSingleResult();
			System.out.println("Max of Age: " + maxValue);
			
			Integer minValue = 
					em.createQuery("select min(m.age) from Member m", Integer.class)
					.getSingleResult();
			System.out.println("Min of Age: " + minValue);			
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}
	
	
	// 평균 나이가 25세 이상인 팀들을 쿼리
	public static void testGroupbyHavingOrderby() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			String query = 
					"SELECT t.name, AVG(m.age) " + // 평균 나이가 25세 이상인 팀들을 쿼리
			        "FROM Team t JOIN t.memberList m " + // 팀에 속한 멤버들에서부터 시작.
					"GROUP BY t.name " + // 팀 이름별로 그룹핑
			        "HAVING AVG(m.age) > 30 " + // 평균 나이가 30세 이상
					"ORDER BY AVG(m.age) DESC ";
			
			@SuppressWarnings("unchecked")
			List<Object[]> objsList = 
					em.createQuery(query)
					.getResultList();
			
			for (Object[] objs : objsList) {
				String teamName = (String)objs[0];
				Double avgAge = (Double)objs[1];
				System.out.println("Team: " + teamName + ", Average Age: " + avgAge);
			}			
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}
	
	public static void setSubQueryInSelect() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			// 각 Member의 name과 해당 Member가 속한 Team의 총 멤버 수를 구하는 쿼리
			String query = 
				"SELECT m.name, " + 
				"(SELECT COUNT(subM) FROM Member subM WHERE subM.team = m.team) " +
					"AS teamMemberCount " +
				"FROM Member m";
			
			@SuppressWarnings("unchecked")
			List<Object[]> objsList = 
					em.createQuery(query)
					.getResultList();
			
			for (Object[] objs : objsList) {
				String memName = (String)objs[0];
				Long count = (Long)objs[1];
				System.out.println("Member name: " + memName + ", count: " + count);
			}			
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}
	
	public static void testSubQueryInWhere() {
		
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			// 팀의 가장 나이가 많은 멤버를 찾는 쿼리
			String query = 
				"SELECT m " + 
			    "FROM Member m " +
			    "WHERE m.age = (SELECT MAX(subM.age) FROM Member subM WHERE subM.team = m.team)";
			
			
			List<Member> memList = 
					em.createQuery(query, Member.class)
					.getResultList();
			
			for (Member m : memList) {
				System.out.println("Team: " + m.getTeam().getName() +
						", Member: " + m.getName() + 
						", Max Age: " + m.getAge());
			}
			
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}		
	}
	
	
	// JPQL은 FROM절에서 서브쿼리를 허용하지 않기 때문에
	// ,네이티브 JOIN sql 쿼리로 풀어야함
    /*
    SELECT m.name, subQuery.teamName
    FROM Member m,
         (SELECT t.TEAM_ID, t.name AS teamName
          FROM Team t
          JOIN Member m ON t.TEAM_ID = m.TEAM_ID
          GROUP BY t.TEAM_ID, t.name
          HAVING AVG(m.age) > 30) AS subQuery
    WHERE m.TEAM_ID = subQuery.TEAM_ID;
     */
	// 굳이 JPA의 Native 쿼리를 작성할 필요가 없음: 직접 SQL 쿼리를 작성해야 한다면, JdbcTemplate을 사용해도 됨! 
	public static void testSubQueryInFromAlternate() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		try {
			tx.begin();
			
			// : 팀의 멤버 평균 나이가 30 이상인 팀의 이름과 그 팀에 속한 멤버들의 이름을 출력
			String query = 
					"SELECT m.name, subQuery.teamName " +
			        "From Member m " +
					"JOIN (SELECT t.TEAM_ID AS team_id, t.name AS teamName " +
			        "      FROM Team t " +
					"      JOIN Member m ON t.TEAM_ID = m.TEAM_ID " +
			        "      GROUP BY t.TEAM_ID, t.name " +
					"      HAVING AVG(m.age) > 30) AS subQuery " +
			        "ON m.TEAM_ID = subQuery.team_id";
			
			Query nativeQuery = em.createNativeQuery(query);
			@SuppressWarnings("unchecked")
			List<Object[]> objsList = nativeQuery.getResultList();
			
			for (Object[] objs : objsList) {
				String memName = (String)objs[0];
				String teamName = (String)objs[1];
				System.out.println("Member name: " + memName + ", Team name: " + teamName);
			}			
			
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}

	public static void testQueryDSLInsert(EntityManager em) {
		System.out.println("+testQueryDSLInsert");

		Member member = new Member();
		member.setName("1stQueryDSLInsert");
		member.setAge(30);

		// QueryDSL은 Insert를 지원하지 않는다.
		// persist 메소드를 사용하면 된다.
		em.persist(member);

		System.out.println("-testQueryDSLInsert");

	}

	public static void testQueryDSLSelect() {

		EntityManager em = emf.createEntityManager();
		JPAQueryFactory queryFactory = new JPAQueryFactory(em);
		EntityTransaction tx = em.getTransaction();

		try {
			tx.begin();

			Member member = new Member();
			member.setName("4thQueryDSLUpdate");
			member.setAge(20);

			em.persist(member);
			em.flush();
			em.clear();

			QMember qMember = QMember.member;
			List<Member> memberList = queryFactory
					.selectFrom(qMember)
							.where(qMember.id.eq(member.getId()))
									.fetch();

			for (Member mem : memberList) {
				System.out.println("Member name: " + mem.getName());
			}

			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}


	public static void testQueryDSLUpdate() {

		EntityManager em = emf.createEntityManager();
		JPAQueryFactory queryFactory = new JPAQueryFactory(em);
		EntityTransaction tx = em.getTransaction();

		try {
			tx.begin();

			Member member = new Member();
			member.setName("2ndQueryDSLUpdate");
			member.setAge(35);

			em.persist(member);
			em.flush();
			em.clear();

			String newName = "New Name2";
			QMember qMember = QMember.member;

			long amountOfAffectedRows = queryFactory
					.update(qMember)
					.set(qMember.name, newName)
					.where(qMember.id.eq(member.getId()))
					.execute();

			System.out.println("amount of affected rows : " + amountOfAffectedRows);
			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}

	public static void testQueryDSLDelete() {
		EntityManager em = emf.createEntityManager();
		JPAQueryFactory queryFactory = new JPAQueryFactory(em);
		EntityTransaction tx = em.getTransaction();

		try {
			tx.begin();

			Member member = new Member();
			member.setName("sungwon");
			member.setAge(30);

			em.persist(member);
			em.flush();
			em.clear();

			QMember qMember = QMember.member;
			long affectedRows = queryFactory
					.delete(qMember)
					.where(qMember.id.eq(member.getId()))
					.execute();

			System.out.println("affected Rows : " + affectedRows);
			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}


	public static void testQueryDSLX() {
		EntityManager em = emf.createEntityManager();
		JPAQueryFactory queryFactory = new JPAQueryFactory(em);
		EntityTransaction tx = em.getTransaction();

		try {
			tx.begin();

			QTeam team = QTeam.team;  // Team 엔티티의 QueryDSL 인스턴스
			QMember member = QMember.member;
			// QueryDSL에서 정의한 클래스.
			// 파이썬에서 Tuple을 지원함: List임. 그러나 불변객체(immutable)
			List<Tuple> result = queryFactory
					.select(team.name, member.age.avg()) // 팀 이름과 평균 나이 선택
					.from(team)
					.join(team.memberList, member)  // 팀과 멤버 리스트를 조인
					.groupBy(team.name)  // 팀 이름으로 그룹핑
					.having(member.age.avg().goe(30))  // 평균 나이가 30세 이상인 팀 : goe는 >= 의미
					.orderBy(member.age.avg().desc())  // 평균 나이 내림차순 정렬
					.fetch();  // 결과 가져오기

			for (Tuple tuple : result) {
				String teamName = tuple.get(team.name);  // 팀 이름 추출
				Double avgAge = tuple.get(member.age.avg());  // 평균 나이 추출

				System.out.println("Team: " + teamName + ", Avg Age: " + avgAge);
			}
			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}

	public static void testPagingAPIByJPQL() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();

		try {
			tx.begin();

			TypedQuery<Member> query =
					em.createQuery("SELECT m FROM Member m ORDER BY m.id DESC", Member.class)
									.setFirstResult(10)
											.setMaxResults(20);
			List<Member> memberList = query.getResultList();
			for (Member member : memberList) {
				System.out.println("member = " + member.getId());
			}

			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}

	}

	public static void testPagingAPIByQueryDSL() {
		EntityManager em = emf.createEntityManager();
		JPAQueryFactory queryFactory = new JPAQueryFactory(em);
		EntityTransaction tx = em.getTransaction();

		try {
			tx.begin();

			QMember member = QMember.member;

			List<Member> memberList = queryFactory
					.selectFrom(member)
					.orderBy(member.id.asc())
					.offset(0)
					.limit(20)
					.fetch();  // 결과 가져오기

			for (Member mem : memberList) {
				System.out.println("member = " + mem.getId());
			}
			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}


	public static Long getLastIdofMember() {
		EntityManager em = emf.createEntityManager();
		JPAQueryFactory queryFactory = new JPAQueryFactory(em);
		EntityTransaction tx = em.getTransaction();

		Long lastMemberId = -1L;
		try {
			tx.begin();


			QMember member = QMember.member;
			lastMemberId = queryFactory
					.select(member.id)
							.from(member)
									.orderBy(member.id.desc())
											.limit(1)
													.fetchOne();


			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}

		return lastMemberId;
	}

	public static Long getPagedMembers(Long lastMemberId, int limit) {
		EntityManager em = emf.createEntityManager();
		JPAQueryFactory queryFactory = new JPAQueryFactory(em);
		EntityTransaction tx = em.getTransaction();
		List<Member> members = null;

		try {
			tx.begin();

			QMember member = QMember.member;

			if (lastMemberId == null) {
				members = queryFactory
						.selectFrom(member)
						.orderBy(member.id.asc())
						.limit(limit)
						.fetch();
			} else {
				members = queryFactory
						.selectFrom(member)
						.where(member.id.gt(lastMemberId))
						.orderBy(member.id.asc())
						.limit(limit)
						.fetch();
			}

			for (Member m : members) {
				System.out.println(m);
			}

			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}

		if (members != null) {
			if (!members.isEmpty()) {
				// members.size() - 1는 members 리스트의 마지막 엘리먼트 인덱스 값
				return members.get(members.size() - 1).getId();
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public static void testPaginaAPIWithoutOffsetByQueryDsl() {
		Long queryedLastMemberId = getLastIdofMember();

		int pageSize = 20;

		// 총 페이지 수
		int totalPages = (MEMBER_NUMBERS + pageSize - 1) / pageSize; // 올림 계산

		Long lastMemberId = null;  // 첫 페이지의 페이징을 위한 코드...

		for (int currentPage = 1; currentPage <= totalPages; currentPage++) {
			System.out.println("Page " + currentPage + ":");

			lastMemberId = getPagedMembers(lastMemberId, pageSize);
		}

		if (queryedLastMemberId == lastMemberId) {
			System.out.println("Okay");
		}
	}

	public static void testFetchJoinByJPQL() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();

		try {
			tx.begin();

			List<Member> memberList =
					em.createQuery("SELECT m from Member m join fetch m.team", Member.class)
									.getResultList();

			for (Member m : memberList) {
				Team team = m.getTeam();
				System.out.println("Member name=" + m.getName() + ", team id=" + team.getId() + ", name=" + team.getName());
			}

			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}

	public static void testFetchJoinByQueryDsl() {
		EntityManager em = emf.createEntityManager();
		JPAQueryFactory queryFactory = new JPAQueryFactory(em);
		EntityTransaction tx = em.getTransaction();

		try {
			tx.begin();

			QMember member = QMember.member;
			QTeam team = QTeam.team;

			List<Member> memberList = queryFactory
					.selectFrom(member)
							.join(member.team, team).fetchJoin()
							.fetch();

			for (Member m : memberList) {
				Team t = m.getTeam();
				System.out.println("Member name=" + m.getName() + ", team id=" + t.getId() + ", name=" + t.getName());
			}


			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}

	public static void testCollectionFetchJoin() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();

		String nameParameter = "team:5";

		try {
			tx.begin();

//			List<Team> teams = em.createQuery("select t from Team t join fetch t.memberList", Team.class)
//							.getResultList();
//
			// One : team
			// Many : Member
			// OneToMany join : 중복된 결과값이 발생함!!!
//			List<Team> teams = em.createQuery("select t from Team t join fetch t.memberList where t.name = :name",
//							Team.class)
//					.setParameter("name", nameParameter)
//			        .getResultList();

			List<Team> teams =
					em.createQuery("select distinct t from Team t join fetch t.memberList where t.name = :name",
							Team.class)
					.setParameter("name", nameParameter)
					.getResultList();

			for (Team t : teams) {
				System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				System.out.printf("Team id:%d \n", t.getId());
				for (Member m : t.getMemberList()) {
					System.out.printf("Member id:%d, Team name:%s \n", m.getId(), m.getTeam());
				}
				System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

			}


			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
	}

}
